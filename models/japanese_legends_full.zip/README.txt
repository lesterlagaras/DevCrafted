Thank you for purchasing the Japanese Legends Cosmetics Pack!

The models in this pack were created by pedravila from the Hibiscus Studios Creative Team.

Need product support? Check out the MCModels Discord and create a ticket.

If you need to merge our resourcepack with a preexisting one, we recommend https://mito.thenuclearnexus.live



1) Install the resource pack provided

2) Open the HMCCosmetics/cosmetics folder, than drag and drop the japanese_legends_vanilla.yml folder into your HMCCosmetics/cosmetics folder.


1) Drag & Drop our Oraxen folder into your main plugins directory, it will automatically merge with your current Oraxen folder.

2) Open the HMCCosmetics/cosmetics folder, than drag and drop the japanese_legends_oraxen.yml folder into your HMCCosmetics/cosmetics folder.


1) Drag & Drop our ItemsAdder folder into your main plugins directory, it will automatically merge with your current ItemsAdder Folder.

2) Open the HMCCosmetics/cosmetics folder, than drag and drop the japanese_legends_itemsadder.yml folder into your HMCCosmetics/cosmetics folder.

Please note that this configuration does not include a menu file, so you will only be able to apply these cosmetics via the /cosmetic apply command,
unless you add them to a menu on your own.

# 341JO1YXT0BEBQ